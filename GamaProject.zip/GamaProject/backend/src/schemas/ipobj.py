from pydantic import BaseModel
from typing import Optional,Union,List

class AuthenticationBase(BaseModel):
    url : Optional[str]
    id: Optional[str]
    secret: Optional[str]
    payload : Optional[dict]
    headers : Optional[dict]

class ApiKeyAuthentication(AuthenticationBase):
    api_key: str

class BearerTokenAuthentication(AuthenticationBase):
    bearer_token: str

class OAuthAuthentication(AuthenticationBase):
    client_id: str
    client_secret: str
    redirect_uri: str
    scope: str

class BasicAuthAuthentication(AuthenticationBase):
    pass

class NoAuthentication(AuthenticationBase):
    pass

class AuthenticationObjectUI(BaseModel):
    auth_type : str
    method : str
    authentication_data : Union[BasicAuthAuthentication, ApiKeyAuthentication, BearerTokenAuthentication, OAuthAuthentication, NoAuthentication]
    response_type: str = "json"
    object_to_store : Optional[str]
    # variables_to_store : Optional[dict]

class IPOBJBase(BaseModel):
    authentication : Optional[AuthenticationObjectUI]
    auth_type :  str
    url : str
    databaseObject : str
    datasource :  str


