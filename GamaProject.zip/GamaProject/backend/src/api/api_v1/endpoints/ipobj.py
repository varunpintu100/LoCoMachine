from fastapi import APIRouter,HTTPException
from src.schemas.ipobj import IPOBJBase
from src.actions.authenticate import authenticate
from src.gen_utils.regex_validator import extract_value


router = APIRouter()


@router.post("/ipobj",status_code=200)
def execute_api_and_write_to_database(
    obj_in : IPOBJBase
):
    if obj_in.authentication:
        try:
            #this method is used if there is any authentication object if present
            auth_response = authenticate(obj_in.authentication)
        except Exception as e:
            return HTTPException(status_code=500,detail={"detail" : f"error occured while authentication !! - {str(e)}"})
        if obj_in.authentication.object_to_store:
            pattern = obj_in.authentication.object_to_store.replace("$","")
            value = extract_value(auth_response,pattern)
            print(auth_response)
    else:
        print("No authentication method found !!")
        
        return value