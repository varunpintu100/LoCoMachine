import re


#this method is used to extract data from the pattern
def extract_value(data, pattern):
    keys = re.split(r'\.|\[|\]', pattern)
    keys = [key for key in keys if key]  # Remove empty strings
    value = data
    for key in keys:
        if key.isdigit():  # Check if the key is a digit for list indexing
            key = int(key)
            if isinstance(value, list) and key < len(value):
                value = value[key]
            else:
                return None
        elif isinstance(value, dict) and key in value:
            value = value[key]
        else:
            return None
    return value

def dict_generator(keys,values) -> dict:
    response_dict = {}
    for idx,key in enumerate(keys):
        response_dict[key] = values[idx]
    return response_dict


def form_object(input_dict, response):
    result = {}
    for key, value in input_dict.items():
        pattern = value.replace("$", "")
        value = extract_value(response, pattern)
        parts = key.split(".")
        for i, part in enumerate(parts):
            if part.endswith("$"):
                part = part[:-1]
                if i == len(parts) - 1:
                    result[part] = value
                else:
                    if part not in result:
                        result[part] = {}
                    result = result[part]
            else:
                result[part] = value
    return result

def form_object_1(input_dict,response):
    result = {}
    for key, value in input_dict.items():
        # pattern = value.replace("$","")
        # value = extract_value(response,pattern)
        parts = key.split(".")
        current = result
        for i, part in enumerate(parts):
            if part.endswith("$"):
                part = part[:-1]
                if i == len(parts) - 1:    
                    current[part] = value
                else:
                    if part not in current:
                        current[part] = {}
                    current = current[part]
            else:
                current[part] = value
                break
    return result
