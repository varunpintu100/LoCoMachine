import requests as re
from requests import Response
import base64


class _token:
    def __init__(self,url,method,headers,payload) -> None:
        self.url = url
        self.method = method
        self.headers = headers
        self.payload = payload
        # This has to optional as we are not going using sdk in the first round
        self.is_sdk = False if self.url else True

    def authenticate(self,)-> None:
        pass

#TODO add other authorization types
class _BasicAuth(_token):
    def __init__(self, url, headers, payload,id,secret,method="POST") -> None:
        super().__init__(url, method, headers, payload)
        self.id = id
        self.key = secret

    def authenticate(self,) -> Response:
        auth_string = 'Basic ' + base64.b64encode(bytes((self.id + ':' + self.key).encode('ascii'))).decode(
            'ascii')
        self.headers["Authorization"] = auth_string
        response = re.request(method=self.method,params=self.payload,headers=self.headers,url=self.url)
        return response

def authentication_picker(type: str):
    if type == "Basic Auth":
        return _BasicAuth