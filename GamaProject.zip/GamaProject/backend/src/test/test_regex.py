from src.gen_utils.regex_validator import form_object

data = {
    "entities": [
        {
            "id": "0",
            "name": "",
            "active": True,
            "defaultCode": True,
            "category": "OnQueueWork",
            "lengthInMinutes": 120,
            "countsAsPaidTime": True,
            "countsAsWorkTime": True,
            "countsTowardShrinkage": False,
            "plannedShrinkage": True,
            "interruptible": True,
            "secondaryPresences": [],
            "metadata": {
                "version": 1,
                "modifiedBy": {
                    "id": "006adaaf-db22-4012-ac33-3db3ce6454d7",
                    "selfUri": "/api/v2/users/006adaaf-db22-4012-ac33-3db3ce6454d7"
                },
                "dateModified": "2024-05-08T06:52:17.801Z"
            },
            "selfUri": "/api/v2/workforcemanagement/businessunits/4a2fcb5b-830f-4def-9839-32c0a4f313cd/activitycodes/0"
        },
        {
            "id": "1",
            "name": "",
            "active": True,
            "defaultCode": True,
            "category": "Break",
            "lengthInMinutes": 15,
            "countsAsPaidTime": True,
            "countsAsWorkTime": False,
            "countsTowardShrinkage": True,
            "plannedShrinkage": True,
            "interruptible": False,
            "secondaryPresences": [],
            "metadata": {
                "version": 1,
                "modifiedBy": {
                    "id": "006adaaf-db22-4012-ac33-3db3ce6454d7",
                    "selfUri": "/api/v2/users/006adaaf-db22-4012-ac33-3db3ce6454d7"
                },
                "dateModified": "2024-05-08T06:52:17.807Z"
            },
            "selfUri": "/api/v2/workforcemanagement/businessunits/4a2fcb5b-830f-4def-9839-32c0a4f313cd/activitycodes/1"
        },
        {
            "id": "2",
            "name": "",
            "active": True,
            "defaultCode": True,
            "category": "Meal",
            "lengthInMinutes": 30,
            "countsAsPaidTime": False,
            "countsAsWorkTime": False,
            "countsTowardShrinkage": True,
            "plannedShrinkage": True,
            "interruptible": False,
            "secondaryPresences": [],
            "metadata": {
                "version": 1,
                "modifiedBy": {
                    "id": "006adaaf-db22-4012-ac33-3db3ce6454d7",
                    "selfUri": "/api/v2/users/006adaaf-db22-4012-ac33-3db3ce6454d7"
                },
                "dateModified": "2024-05-08T06:52:17.807Z"
            },
            "selfUri": "/api/v2/workforcemanagement/businessunits/4a2fcb5b-830f-4def-9839-32c0a4f313cd/activitycodes/2"
        },
        {
            "id": "3",
            "name": "",
            "active": True,
            "defaultCode": True,
            "category": "Meeting",
            "lengthInMinutes": 30,
            "countsAsPaidTime": True,
            "countsAsWorkTime": True,
            "countsTowardShrinkage": True,
            "plannedShrinkage": True,
            "interruptible": False,
            "secondaryPresences": [],
            "metadata": {
                "version": 1,
                "modifiedBy": {
                    "id": "006adaaf-db22-4012-ac33-3db3ce6454d7",
                    "selfUri": "/api/v2/users/006adaaf-db22-4012-ac33-3db3ce6454d7"
                },
                "dateModified": "2024-05-08T06:52:17.807Z"
            },
            "selfUri": "/api/v2/workforcemanagement/businessunits/4a2fcb5b-830f-4def-9839-32c0a4f313cd/activitycodes/3"
        },
        {
            "id": "4",
            "name": "",
            "active": True,
            "defaultCode": True,
            "category": "OffQueueWork",
            "lengthInMinutes": 60,
            "countsAsPaidTime": True,
            "countsAsWorkTime": True,
            "countsTowardShrinkage": True,
            "plannedShrinkage": True,
            "interruptible": False,
            "secondaryPresences": [],
            "metadata": {
                "version": 1,
                "modifiedBy": {
                    "id": "006adaaf-db22-4012-ac33-3db3ce6454d7",
                    "selfUri": "/api/v2/users/006adaaf-db22-4012-ac33-3db3ce6454d7"
                },
                "dateModified": "2024-05-08T06:52:17.807Z"
            },
            "selfUri": "/api/v2/workforcemanagement/businessunits/4a2fcb5b-830f-4def-9839-32c0a4f313cd/activitycodes/4"
        },
        {
            "id": "5",
            "name": "",
            "active": True,
            "defaultCode": True,
            "category": "TimeOff",
            "lengthInMinutes": 120,
            "countsAsPaidTime": False,
            "countsAsWorkTime": False,
            "agentTimeOffSelectable": True,
            "countsTowardShrinkage": True,
            "plannedShrinkage": True,
            "interruptible": False,
            "secondaryPresences": [],
            "metadata": {
                "version": 1,
                "modifiedBy": {
                    "id": "006adaaf-db22-4012-ac33-3db3ce6454d7",
                    "selfUri": "/api/v2/users/006adaaf-db22-4012-ac33-3db3ce6454d7"
                },
                "dateModified": "2024-05-08T06:52:17.807Z"
            },
            "selfUri": "/api/v2/workforcemanagement/businessunits/4a2fcb5b-830f-4def-9839-32c0a4f313cd/activitycodes/5"
        },
        {
            "id": "89d60ade-1efc-4db4-b367-77617fcbcb77",
            "name": "Sick",
            "active": True,
            "defaultCode": False,
            "category": "TimeOff",
            "lengthInMinutes": 120,
            "countsAsPaidTime": False,
            "countsAsWorkTime": False,
            "agentTimeOffSelectable": True,
            "countsTowardShrinkage": True,
            "plannedShrinkage": False,
            "interruptible": False,
            "secondaryPresences": [],
            "metadata": {
                "version": 1,
                "modifiedBy": {
                    "id": "006adaaf-db22-4012-ac33-3db3ce6454d7",
                    "selfUri": "/api/v2/users/006adaaf-db22-4012-ac33-3db3ce6454d7"
                },
                "dateModified": "2024-05-08T07:06:15.343Z"
            },
            "selfUri": "/api/v2/workforcemanagement/businessunits/4a2fcb5b-830f-4def-9839-32c0a4f313cd/activitycodes/89d60ade-1efc-4db4-b367-77617fcbcb77"
        },
        {
            "id": "6",
            "name": "",
            "active": True,
            "defaultCode": True,
            "category": "Training",
            "lengthInMinutes": 30,
            "countsAsPaidTime": True,
            "countsAsWorkTime": True,
            "countsTowardShrinkage": True,
            "plannedShrinkage": True,
            "interruptible": False,
            "secondaryPresences": [],
            "metadata": {
                "version": 1,
                "modifiedBy": {
                    "id": "006adaaf-db22-4012-ac33-3db3ce6454d7",
                    "selfUri": "/api/v2/users/006adaaf-db22-4012-ac33-3db3ce6454d7"
                },
                "dateModified": "2024-05-08T06:52:17.807Z"
            },
            "selfUri": "/api/v2/workforcemanagement/businessunits/4a2fcb5b-830f-4def-9839-32c0a4f313cd/activitycodes/6"
        },
        {
            "id": "7",
            "name": "",
            "active": True,
            "defaultCode": True,
            "category": "Unavailable",
            "lengthInMinutes": 60,
            "countsAsPaidTime": False,
            "countsAsWorkTime": False,
            "countsTowardShrinkage": True,
            "plannedShrinkage": True,
            "interruptible": False,
            "secondaryPresences": [],
            "metadata": {
                "version": 1,
                "modifiedBy": {
                    "id": "006adaaf-db22-4012-ac33-3db3ce6454d7",
                    "selfUri": "/api/v2/users/006adaaf-db22-4012-ac33-3db3ce6454d7"
                },
                "dateModified": "2024-05-08T06:52:17.807Z"
            },
            "selfUri": "/api/v2/workforcemanagement/businessunits/4a2fcb5b-830f-4def-9839-32c0a4f313cd/activitycodes/7"
        },
        {
            "id": "c48a7bf5-b62e-4e35-b7f1-4f5ce4f554bd",
            "name": "OFF_WORK",
            "active": False,
            "defaultCode": False,
            "category": "Unavailable",
            "lengthInMinutes": 5,
            "countsAsPaidTime": False,
            "countsAsWorkTime": False,
            "countsTowardShrinkage": True,
            "plannedShrinkage": True,
            "interruptible": False,
            "secondaryPresences": [],
            "metadata": {
                "version": 1,
                "modifiedBy": {
                    "id": "System",
                    "selfUri": "/api/v2/users/System"
                },
                "dateModified": "2024-05-08T06:52:27.433Z"
            },
            "selfUri": "/api/v2/workforcemanagement/businessunits/4a2fcb5b-830f-4def-9839-32c0a4f313cd/activitycodes/c48a7bf5-b62e-4e35-b7f1-4f5ce4f554bd"
        },
        {
            "id": "675f4936-d5aa-40dc-9b63-c500081ee862",
            "name": "Coffee Break",
            "active": False,
            "defaultCode": False,
            "category": "Break",
            "lengthInMinutes": 15,
            "countsAsPaidTime": True,
            "countsAsWorkTime": False,
            "countsTowardShrinkage": True,
            "plannedShrinkage": True,
            "interruptible": False,
            "secondaryPresences": [],
            "metadata": {
                "version": 1,
                "modifiedBy": {
                    "id": "System",
                    "selfUri": "/api/v2/users/System"
                },
                "dateModified": "2024-05-08T06:52:27.433Z"
            },
            "selfUri": "/api/v2/workforcemanagement/businessunits/4a2fcb5b-830f-4def-9839-32c0a4f313cd/activitycodes/675f4936-d5aa-40dc-9b63-c500081ee862"
        }
    ]
}

input_dict = { 
    "wfm.id.id$" : "$entities[0].id",
    "wfm.name.id$" : "$entities[0].name"
}


print(form_object(input_dict=input_dict,response=data))