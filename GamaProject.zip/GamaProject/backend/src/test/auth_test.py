import PureCloudPlatformClientV2

region_url = PureCloudPlatformClientV2.PureCloudRegionHosts["us_east_1"]
PureCloudPlatformClientV2.configuration.host = region_url.get_api_host()
__api_client = PureCloudPlatformClientV2.api_client.ApiClient().get_client_credentials_token(
    'c73f6add-c285-4d60-b468-93d91d047a77','06G1NPus8Xv--UHuRMyL5JA18mKLxWpzkvs_pWCjCso'
)
print(__api_client)


# eval(code)