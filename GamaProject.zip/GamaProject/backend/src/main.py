from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from starlette.middleware.cors import CORSMiddleware
from pathlib import Path

from src.api.api_v1.api import api_router

BACKEND_CORS_ORIGINS = ["https://localhost:3000","https://10.10.5.94:3000","http://localhost:5500","http://127.0.0.1:5500"]

app = FastAPI(
    title="P_1",
    openapi_url="/api/v1/openapi.json",
    swagger_ui_parameters={"docExpansion": "none"},
)

# Set all CORS enabled origins
if BACKEND_CORS_ORIGINS:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[str(origin) for origin in BACKEND_CORS_ORIGINS],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

app.include_router(api_router, prefix="/api/v1")