class AuthenticationError(Exception):
    pass