from src.authenticate.authenticate import authentication_picker
from src.schemas.ipobj import AuthenticationObjectUI
from src.errors.authenticationErrors import AuthenticationError

def authenticate(obj_in : AuthenticationObjectUI):
    auth_obj = authentication_picker(obj_in.auth_type)
    auth_obj = auth_obj(method=obj_in.method,**obj_in.authentication_data.__dict__)
    try:
        authenticate = auth_obj.authenticate()
        if obj_in.response_type == "json":
            auth_response = authenticate.json()
        else:
            auth_response = authenticate.content
    except Exception as e:
        raise AuthenticationError(f"Error occured while authentication {str(e)}")
    return auth_response